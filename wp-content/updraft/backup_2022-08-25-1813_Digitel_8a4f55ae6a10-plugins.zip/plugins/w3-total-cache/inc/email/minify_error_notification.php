<html>
	<head></head>
	<body>
		<p>Unfortunately, an error occurred while creating the minify cache. Please check your settings to ensure your site is working as intended.</p>
		<p>Thanks for using W3 Total Cache.</p>
	</body>
</html>
